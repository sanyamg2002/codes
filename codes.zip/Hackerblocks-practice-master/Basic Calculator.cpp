#include<iostream>
using namespace std;
int main() {
	int N1,N2;
	char ch;
	int op;
	cin>>ch;
	do{
		if(ch=='+')
		{
			cin>>N1;
			cin>>N2;
			op=N1+N2;
			cout<<op<<endl;
		}
		else if(ch=='-')
		{
			cin>>N1;
			cin>>N2;
			op=N1-N2;
			cout<<op<<endl;
		}
		else if(ch=='*')
		{
			cin>>N1;
			cin>>N2;
			op=N1*N2;
			cout<<op<<endl;
		}
		else if( ch=='/')
		{
			cin>>N1;
			cin>>N2;
			op=N1/N2;
			cout<<op<<endl;
		}
		else if( ch=='%')
		{
			cin>>N1;
			cin>>N2;
			op=N1%N2;
			cout<<op<<endl;
		}
		else if(ch=='X' || ch=='x')
		{
			break;
		}
		else{
			cout<<"Invalid operation. Try again."<<endl;
		}
		cin>>ch;
	} while(ch!='\0');
	return 0;
}
