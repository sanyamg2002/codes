#include<iostream>
int main(){
    std::cout<<6;
    return 0;
}
