#include<iostream>
using namespace std;
int main(){
	int i,sum=0;
	while(sum>=0)
	{	
		cin>>i;
		sum=sum+i;
		if(sum<0){
				break;
			}
		cout<<i<<endl;
		
  }
}
