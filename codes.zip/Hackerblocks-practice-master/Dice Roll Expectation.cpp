#include<iostream>
int main(){
    std::cout<<15;
    return 0;
}
