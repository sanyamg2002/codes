#include<bits/stdc++.h>
using namespace std;
int main () {
cout<<7;
return 0;
}
